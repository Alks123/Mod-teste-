package com.minhafoto;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.minecraft.core.Registry;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.component.CustomData;

public class MinhaFoto implements ModInitializer {
    public static final String MOD_ID = "minha_foto";

    // {id da variante, nome mostrado no item}
    private static final String[][] QUADROS = {
        {"selfie", "Minha foto (grande)"},
        {"selfie_small", "Minha foto (pequeno)"},
        {"ada", "Ada Wong (grande)"},
        {"ada_small", "Ada Wong (pequeno)"},
        {"wanda", "Wanda (grande)"},
        {"wanda_small", "Wanda (pequeno)"},
        {"claire", "Claire (grande)"},
        {"claire_small", "Claire (pequeno)"}
    };

    private static ItemStack quadro(String id, String nome) {
        ItemStack stack = new ItemStack(Items.PAINTING);
        CompoundTag tag = new CompoundTag();
        tag.putString("id", "minecraft:painting");
        tag.putString("variant", MOD_ID + ":" + id);
        stack.set(DataComponents.ENTITY_DATA, CustomData.of(tag));
        stack.set(DataComponents.ITEM_NAME, Component.literal(nome));
        return stack;
    }

    @Override
    public void onInitialize() {
        CreativeModeTab aba = FabricItemGroup.builder()
                .title(Component.translatable("itemGroup." + MOD_ID + ".quadros"))
                .icon(() -> quadro("selfie", "Minha foto (grande)"))
                .displayItems((params, output) -> {
                    for (String[] q : QUADROS) {
                        output.accept(quadro(q[0], q[1]));
                    }
                })
                .build();

        Registry.register(BuiltInRegistries.CREATIVE_MODE_TAB,
                ResourceLocation.fromNamespaceAndPath(MOD_ID, "quadros"), aba);
    }
}
